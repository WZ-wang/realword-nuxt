import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _e1bd3b2a = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _4eba3860 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _ee75c7f0 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _226751b8 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _f95aeea4 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _2bdf4dd5 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))
const _45150a88 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _e1bd3b2a,
    children: [{
      path: "",
      component: _4eba3860,
      name: "home"
    }, {
      path: "/login",
      component: _ee75c7f0,
      name: "login"
    }, {
      path: "/register",
      component: _ee75c7f0,
      name: "register"
    }, {
      path: "/settings",
      component: _226751b8,
      name: "settings"
    }, {
      path: "/editor",
      component: _f95aeea4,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _2bdf4dd5,
      name: "article"
    }, {
      path: "/profile/:username",
      component: _45150a88,
      name: "profile"
    }]
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
